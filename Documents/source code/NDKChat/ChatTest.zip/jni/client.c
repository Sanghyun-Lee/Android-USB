/*client side*/
#include<stdio.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/socket.h>
#include<stdlib.h>
#include<unistd.h>

#define MAXLINE 1024

int main()
{
	int sd,con,port,i,pid;
	char content[MAXLINE], ip_addr[MAXLINE], content_recv[MAXLINE];
	struct sockaddr_in cli;

	if((sd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP))==-1)
	{
		printf("\nSocket problem");
		return 0;
	}

	bzero((char*)&cli,sizeof(cli));
	cli.sin_family = AF_INET;
	printf("ENTER IP NO: ");    
	gets(ip_addr);
	cli.sin_addr.s_addr = inet_addr(ip_addr);
	printf("ENTER PORT NO: ");
	scanf("%d",&port);
	cli.sin_port=htons(port);
	// cli.sin_addr.s_addr=htonl(INADDR_ANY);

	con=connect(sd,(struct sockaddr*)&cli,sizeof(cli));

	if(con==-1)
	{
		printf("\nConnection error");
		return 0;
	}

	pid = fork();

	if(pid>0)
	{
		printf("Enter the data to be send type exit for stop:\n");
		gets(content);
		strcat(content, "\n");

		while(strcmp(content,"exit")!=0)
		{
			send(sd,content,MAXLINE,0);
			gets(content);
			strcat(content, "\n");

		}
		// send(sd,"exit",5,0);
	}
	else if(pid==0)
	{
		while(1)
		{
			memset(content_recv, 0x00, MAXLINE);
			i=recv(sd,content_recv,MAXLINE,0);
			if(strcmp(content_recv, "exit")==0){
				break;
			}
			printf("Server: %s\n",content_recv);

		}
		// send(sd,"exit",5,0);
	}
	else {
		printf("fail\n");
	}
	close(sd);
	return 0;
}

