#include "Message.h"

#include<stdio.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/socket.h>
#include<stdlib.h>
#include<unistd.h>

#define MAXLINE 1024

struct sockaddr_in cli;
int sd;


JNIEXPORT jint JNICALL Java_test_chat_Message_set_1ip_1port
(JNIEnv *env, jobject obj, jstring jstr_ip, jint port) {
	int con;
	// char ip_addr[MAXLINE];
	const char *ip_addr;
	int len;

	len = (*env)->GetStringUTFLength(env, jstr_ip);
	ip_addr = (*env)->GetStringUTFChars(env, jstr_ip, NULL);
	if(ip_addr == NULL) {
		return -1;
	}
	//strcpy(ip_addr, str);

	if((sd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP))==-1)
	{
		printf("\nSocket problem");
		return -1;
	}

	bzero((char*)&cli,sizeof(cli));
	cli.sin_family = AF_INET;
	// printf("ENTER IP NO: ");    
	// gets(ip_addr);
	cli.sin_addr.s_addr = inet_addr(ip_addr);
	// printf("ENTER PORT NO: ");
	// scanf("%d",&port);
	cli.sin_port=htons(port);
	// cli.sin_addr.s_addr=htonl(INADDR_ANY);

	con=connect(sd,(struct sockaddr*)&cli,sizeof(cli));

	if(con==-1)
	{
		printf("\nConnection error");
		return -2;
	}
	return 0;
}


JNIEXPORT jint JNICALL Java_test_chat_Message_send_1msg
(JNIEnv *env, jobject obj, jstring jstr) {
	char content[MAXLINE];
	char temp[MAXLINE];
	const jbyte *str;
	int len;

	len = (*env)->GetStringUTFLength(env, jstr);
	str = (*env)->GetStringUTFChars(env, jstr, NULL);
	if(str == NULL) {
		return -1;
	}
	strcpy(content, str);
	strcat(content, "\n");

	return send(sd,content,MAXLINE,0);
}


JNIEXPORT jstring JNICALL Java_test_chat_Message_recv_1msg
(JNIEnv *env, jclass jcls) {
	char content_recv[MAXLINE];
	int i;
	jstring str;

	memset(content_recv, 0x00, MAXLINE);
	i=recv(sd,content_recv,MAXLINE,0);
	str = (*env)->NewStringUTF(env, content_recv);

	return str;
}